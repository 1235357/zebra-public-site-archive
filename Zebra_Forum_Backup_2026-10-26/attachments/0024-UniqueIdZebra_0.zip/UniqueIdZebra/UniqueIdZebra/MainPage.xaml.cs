﻿using CommunityToolkit.Mvvm.Messaging;

namespace UniqueIdZebra
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();

            WeakReferenceMessenger.Default.Register<string>(this, (r, m) =>
            {
                MainThread.BeginInvokeOnMainThread(() => { 
                    SerialNumberLabel.Text = m; 
                });
            });
        }
    }

}
