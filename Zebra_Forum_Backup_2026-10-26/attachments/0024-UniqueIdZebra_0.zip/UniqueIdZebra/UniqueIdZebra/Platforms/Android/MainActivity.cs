﻿using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Util;
using CommunityToolkit.Mvvm.Messaging;
using Symbol.XamarinEMDK;
using static Java.Util.Jar.Attributes;
using static Symbol.XamarinEMDK.EMDKManager;

namespace UniqueIdZebra
{
    [Activity(Theme = "@style/Maui.SplashTheme", MainLauncher = true, LaunchMode = LaunchMode.SingleTop, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation | ConfigChanges.UiMode | ConfigChanges.ScreenLayout | ConfigChanges.SmallestScreenSize | ConfigChanges.Density)]
    public class MainActivity : MauiAppCompatActivity, IEMDKListener
    {
        private EMDKManager emdkManager = null;
        private ProfileManager profileManager = null;

        private readonly string SERIAL_URI = "content://oem_info/oem.zebra.secure/build_serial";

        protected override void OnCreate(Bundle? savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public void OnClosed()
        {
            if(emdkManager != null)
            {
                emdkManager.Release();
                emdkManager = null;
            }
        }

        public void OnOpened(EMDKManager p0)
        {
            emdkManager = p0;

            profileManager = (ProfileManager)emdkManager.GetInstance(FEATURE_TYPE.Profile);

            if (profileManager != null)
            {
                var result = profileManager.ProcessProfile("SerialPermission", ProfileManager.PROFILE_FLAG.Set, GetSerialPermissionXml());
                Log.Debug("OnOpened", $"ProcessProfile result: {result.StatusCode}");

                var cursor = ContentResolver?.Query(Android.Net.Uri.Parse(SERIAL_URI)!, null, null, null, null);

                if (cursor != null)
                {
                    Log.Debug("OnOpened", $"Cursor count: {cursor.Count}");
                    while (cursor.MoveToNext())
                    {
                        var col1 = cursor.GetString(0);
                        Log.Debug("OnOpened", $"Column value: {col1}");
                    }
                    if (cursor.MoveToFirst())
                    {
                        var serial = cursor.GetString(0);
                        WeakReferenceMessenger.Default.Send<string>(serial);
                    }
                    cursor.Close();
                }
                else
                {
                    Log.Debug("OnOpened", "Cursor is null");
                }
            }
            else
            {
                Log.Debug("OnOpened", "ProfileManager is null");
            }
        }

        protected override void OnPostCreate(Bundle? savedInstanceState)
        {
            base.OnPostCreate(savedInstanceState);

            GetEMDKManager(ApplicationContext, this);
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();

            if (profileManager != null)
                profileManager = null;

            if(emdkManager != null)
            {
                emdkManager.Release();
                emdkManager = null;
            }
        }

        private string[] GetSerialPermissionXml()
        {
            var extraData = new string[1];
            //extraData[0] = "<wap-provisioningdoc>\n" +
            //" <characteristic type=\"Profile\">\n" +
            //" <parm name=\"ProfileName\" value=\"SerialPermission\"/>\n" +
            //" <characteristic version=\"8.3\" type=\"AccessMgr\">\n" +
            //" <parm name=\"OperationMode\" value=\"1\" />\n" +
            //" <parm name=\"ServiceAccessAction\" value=\"4\" />\n" +
            //" <parm name=\"ServiceIdentifier\" value=\"content://oem_info/oem.zebra.secure/build_serial\" />\n" +
            //$" <parm name=\"CallerPackageName\" value=\"{PackageName}\" />\n" +
            //$" <parm name=\"CallerSignature\" value=\"{GetPackageSignature(this)}\" />\n" +
            //" </characteristic>\n" +
            //" </characteristic>\n" +
            //"</wap-provisioningdoc>";

            extraData[0] = "<wap-provisioningdoc>" +
                "<characteristic type = \"Profile\">" +
                "<parm name=\"ProfileName\" value=\"SerialProfile\" />" +
                "<characteristic type = \"AccessMgr\" version = \"8.3\" >" +
                "<parm name = \"OperationMode\" value = \"1\" />" +
                "<parm name = \"ServiceAccessAction\" value = \"4\" />" +
                "<parm name = \"ServiceIdentifier\" value = \"content://oem_info/oem.zebra.secure/build_serial\" />" +
                "<parm name = \"CallerPackageName\" value = \"com.companyname.uniqueidzebra\" />" +
                "<parm name = \"CallerSignature\" value = \"MIIC5DCCAcwCAQEwDQYJKoZIhvcNAQELBQAwNzEWMBQGA1UEAwwNQW5kcm9pZCBEZWJ1ZzEQMA4GA1UECgwHQW5kcm9pZDELMAkGA1UEBhMCVVMwIBcNMjMxMDEzMTcxOTM3WhgPMjA1MzEwMDUxNzE5MzdaMDcxFjAUBgNVBAMMDUFuZHJvaWQgRGVidWcxEDAOBgNVBAoMB0FuZHJvaWQxCzAJBgNVBAYTAlVTMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2mecWo1fzRtuMWZ8gbFriNhSHlv+8Ezp3hT78csCMq6CrXNwfI8idSzsGffIyH+jqwsP0oUTlzceh00pLQk+3MTqcoGToHNV9g96elnijAGk12xPNGXES4Kx54wsI5ZSeEuerH0kdlyMVq1aoDXqBQcu/SKLUx3jrIz/u1ezN1QrU8LkC5N/MYONsMnFaR0z3TTseXNtplZzqs5nKKrf7gSKXrHikPoN0EpNOE6rbU0ZnfEwG/I3I1/hCGJt+myCjqpRpvMJeIa1JE2/3wbJIV/HcIiWZg/jXXI2NEbo4bUv+2wln9iklEZKalg78b5AVmhq9XETclzyJf/7ijcv8QIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQB830h1KcME/wAt1kZIFB0nhl5Xk5/SuqG7F91t5yqOLFyyqHkuTxCW9pt9ZMGIwFeyVxoZ8mPyvmltQJ/ErRrHbq8TmUnQoCs7w8JOPxKUILqKSv1TKICQZHuIcOwJB+ZU5IeIdEpMppFhLW8xIqRnZU9JW+6r2U7Cxw6qWn5xpYehKD4j3K6L0GsDFBR1F22NW0OrKnzwxGSDml7yQe1w9ciHhh/SwzO46new3LLCcGERxkeP/fOEb0oNcyTxuPywvnEIXMU7tF9zraMESO2qFhsVTh38SGeAERj8FiyStdm6uQNJ60GeseJHDFExUZHScP2/KiXYGUH7wFRl6DCL\" />" +
                "</characteristic>" +
                "</characteristic>" +
                "</wap-provisioningdoc>";

            return extraData;
        }

        private static string GetPackageSignature(Context context)
        {
            Signature[] sigs;
            SigningInfo signingInfo;
            if (Build.VERSION.SdkInt >= BuildVersionCodes.P)
            {
                signingInfo = context.PackageManager.GetPackageInfo(context.PackageName, PackageInfoFlags.SigningCertificates).SigningInfo;

                sigs = signingInfo.GetApkContentsSigners();
            }
            else
            {
                sigs = (Signature[])context.PackageManager.GetPackageInfo(context.PackageName, PackageInfoFlags.Signatures).Signatures;
            }
            char[] signatureAsChars = sigs[0].ToChars();
            byte[] decodeHex = StringToByteArray(new string(signatureAsChars));
            return Base64.EncodeToString(decodeHex, Base64Flags.NoWrap);
        }

        public static byte[] StringToByteArray(string hex)
        {
            //  https://stackoverflow.com/questions/24108005/convert-hex-string-to-byte-array
            if ((hex.Length % 2) != 0)
                hex = "0" + hex;

            return Enumerable.Range(0, hex.Length)
                             .Where(x => x % 2 == 0)
                             .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
                             .ToArray();
        }
    }
}
